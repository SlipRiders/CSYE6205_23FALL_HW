/*----------------------------------------------------------------
Copyright (c) 2022 Author: Jagadeesh Vasudevamurthy
file: sarray.h
-----------------------------------------------------------------*/
#pragma once

#include "../util/util.h"

#define T int

//MUST Attach two outputs with and without move
//#define MOVE


class Sarray {
public:
		

#ifdef MOVE
		//WRITE CODE
#endif

		

		static bool show;
		static unsigned long long num_allocated;
		static unsigned long long num_freed;


private:
		unsigned size_;
		T* ptr_;

		//private funcions
		
};



