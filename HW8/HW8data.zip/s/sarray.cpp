/*----------------------------------------------------------------
Copyright (c) 2022 Author: Jagadeesh Vasudevamurthy
file: sarray.cpp
-----------------------------------------------------------------*/

#include "sarray.h"

bool Sarray::show = false;
unsigned long long Sarray::num_allocated = 0;
unsigned long long Sarray::num_freed = 0;

